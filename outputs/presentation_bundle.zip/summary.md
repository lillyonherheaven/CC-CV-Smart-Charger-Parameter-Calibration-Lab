# CC/CV Laboratory Diagnostic Summary

Each section has independent inputs; inspect its own settings before comparing results.

Synthetic data are not physical validation. Calibration metrics are in-sample.
The affine OCV model drives the engine and fit; curved OCV is a separate physics illustration.
At fixed SoC, charging-current slope is +R; discharge-current slope is −R.
Full CV equilibrium is asymptotic; practical completion uses a current cutoff.

Complete machine-readable settings are in `diagnostics.json`; numeric tables are in `tables/`.

## Calibration

Status: `ftol` termination condition is satisfied.


## Calibrated Parameters

| parameter | value | unit |
|---|---|---|
| capacity_ah | 2.12047 | Ah |
| current_a | 1 | A |
| resistance_ohm | 0.180326 | ohm |
| eta | 0.995 | fraction |
| ocv_empty_v | 3 | V |
| ocv_slope_v | 1.2 | V/SoC fraction |
| vmax_v | 4.2 | V |
| soc0 | 0.230449 | fraction |
| cutoff_a | 0.1 | A |
| mode | CC/CV | categorical |
| tau_sec | 1152.89 | s |

## Numerical Metrics

| unit | channel | n | MAE | RMSE | max_error |
|---|---|---|---|---|---|
| V | voltage_v | 152 | 2.16201e-16 | 3.97858e-16 | 8.88178e-16 |
| A | current_a | 152 | 1.53746e-08 | 2.5863e-08 | 6.05982e-08 |
| fraction | soc_est | 152 | 1.92182e-09 | 3.23288e-09 | 7.57478e-09 |

## Experimental Metrics

| unit | channel | n | MAE | RMSE | max_error | fit |
|---|---|---|---|---|---|---|
| V | voltage_v | 71 | 0.0277902 | 0.0351153 | 0.0709954 | Before |
| A | current_a | 71 | 0.0212579 | 0.0302986 | 0.0936473 | Before |
| fraction | soc_est | 71 | 0.0120155 | 0.0144963 | 0.0318419 | Before |
| V | voltage_v | 71 | 0.00488783 | 0.00606484 | 0.0189054 | After |
| A | current_a | 71 | 0.00749111 | 0.00896586 | 0.0197901 | After |
| fraction | soc_est | 71 | 0.00239883 | 0.00316637 | 0.0112981 | After |

## Figures

![calibrated overlay](figures/calibrated_overlay.png)

![charging curves](figures/charging_curves.png)

![convergence](figures/convergence.png)

![phase line](figures/phase_line.png)

![physics relationships](figures/physics_relationships.png)

![residuals](figures/residuals.png)

