"""Independent teaching labs. Run: python -m streamlit run app.py."""
from dataclasses import asdict
from pathlib import Path
import hashlib
import json
import pandas as pd
import matplotlib.pyplot as plt
import streamlit as st
from charger.model import Parameters, exact, exact_events, exact_target_time
from charger.solvers import solve, target_time, convergence
from charger.data import sample_data, load_csv, CHANNELS
from charger.analysis import comparison, calibrate, local_defects
from charger.plots import charging_figure, residual_figure, convergence_figure, physics_figure, png_bytes
from charger.export import build_bundle, parameter_table, json_safe

ROOT = Path(__file__).resolve().parent
st.set_page_config(page_title="CC/CV Calibration Lab", page_icon="🔋", layout="wide")
st.title("CC/CV Smart Charger & Parameter Calibration Lab")
st.caption("Math 3 • Independent calculation sections • No hardware control")
st.info("Each tab has its own inputs and Calculate button. Calibration changes only Section 3. "
        "Match settings explicitly when comparing sections. ZIP export records every section's settings.")


def physical_inputs(prefix):
    """Namespaced widget keys prevent any tab from changing another tab's model."""
    l, r = st.columns(2)
    with l:
        mode = st.selectbox("Charging mode", ["CC/CV", "CC"], key=prefix+"mode")
        q = st.number_input("Capacity Q (Ah)", .1, 10., 2., .1, key=prefix+"q")
        current = st.number_input("CC current (A)", .05, 5., 1., .05, key=prefix+"current")
        resistance = st.number_input("Internal resistance (Ω)", .005, 1., .15, .005, format="%.3f", key=prefix+"r")
        soc0 = st.slider("Initial SoC (fraction)", 0., .99, .2, .01, key=prefix+"soc0")
    with r:
        a = st.number_input("OCV intercept a (V)", 2.5, 3.5, 3., .05, key=prefix+"a")
        b = st.number_input("OCV slope b (V / SoC fraction)", .5, 1.8, 1.2, .05, key=prefix+"b")
        vmax = st.number_input("CV voltage Vmax (V)", 3.5, 4.35, 4.2, .01, key=prefix+"vmax")
        cutoff = st.number_input("Termination current (A)", .001, 1., .1, .01, format="%.3f", key=prefix+"cutoff")
        eta = st.slider("Coulombic efficiency", .90, 1., .995, .001, key=prefix+"eta")
    return Parameters(q, current, resistance, eta, a, b, vmax, soc0, cutoff, mode)


def freeze_plot(fig):
    try: return png_bytes(fig, dpi=300)
    finally: plt.close(fig)


@st.cache_data(max_entries=12, show_spinner=False)
def simulation_result(p, duration, dt, method, policy, terminate, target):
    p.validate()
    sim = solve(p, duration, dt, method, policy, terminate)
    obs = sim.observations(p)
    ts, stop = exact_events(p, terminate)
    full = exact_target_time(p, 1., terminate)
    result = {"parameters": asdict(p), "duration_sec": duration, "dt_sec": dt,
              "method": method, "policy": policy, "termination": terminate,
              "tau_sec": p.tau, "exact_switch_sec": ts, "detected_switch_sec": sim.switch_time,
              "exact_stop_sec": stop, "detected_stop_sec": sim.stop_time,
              "target_soc": target, "exact_target_sec": exact_target_time(p, target, terminate),
            "numerical_target_sec": target_time(sim, target), "time_to_100_percent_sec": full,
              "full_charge_note": "100% is asymptotic/unreachable in regulated CV; practical completion uses current cutoff." if full is None else "Unregulated CC reaches 100% mathematically; hardware safety limits still apply."}
    trajectory = pd.DataFrame({"time_sec": sim.time, **obs, "phase": sim.phase})
    errors = comparison(pd.DataFrame(exact(p, sim.time, terminate)), obs)
    return result, trajectory, errors, freeze_plot(charging_figure(p, duration, sim=sim, terminate=terminate))


@st.cache_data(max_entries=12, show_spinner=False)
def numerical_result(p, duration, dt):
    p.validate()
    steps = [dt/4, dt/2, dt, dt*2]
    rows = pd.DataFrame(convergence(p, duration, steps, terminate=False))
    errors = []
    for method in ("Euler", "Heun", "RK4"):
        sim = solve(p, duration, dt, method, "Event-aware", terminate=False)
        errors.append(comparison(pd.DataFrame(exact(p, sim.time, False)), sim.observations(p)).assign(method=method))
    return rows, pd.concat(errors, ignore_index=True), local_defects(p, steps), freeze_plot(convergence_figure(rows))


@st.cache_data(max_entries=12, show_spinner=False)
def calibration_figures(base, fitted, frame, terminate, label):
    duration = max(float(frame.time_sec.max()), 60.)
    pred = exact(fitted, frame.time_sec.to_numpy(), terminate)
    overlay = freeze_plot(charging_figure(fitted, duration, data=frame, terminate=terminate,
                                        data_label=label, baseline=base))
    residual = freeze_plot(residual_figure(frame, pred))
    table = pd.DataFrame({"time_sec": frame.time_sec})
    for c in CHANNELS:
        table[c+"_predicted"] = pred[c]
        if c in frame: table[c+"_residual"] = frame[c]-pred[c]
    return overlay, residual, table


@st.cache_data(max_entries=12, show_spinner=False)
def physics_result(p, fixed_soc, curvature):
    fig, tables = physics_figure(p, fixed_soc, curvature)
    return freeze_plot(fig), tables


def time_text(value):
    return "Not reached / N/A" if value is None else f"{value:.2f} s"


report = {"model": "Affine OCV, isothermal, no polarization", "sections": {}, "errors": {},
          "notes": ["Sections use independent physical inputs.", "Synthetic data are not physical validation.",
                    "Calibration metrics are in-sample.", "Curved OCV is a separate illustration, not the engine's law."]}
tables, figures = {}, {}
tabs = st.tabs(["1 · CC/CV Simulation Engine", "2 · Numerical Solver & Convergence Lab",
                "3 · Experimental Overlay & Calibration", "Physics Relationships", "One-click ZIP Export"])

with tabs[0]:
    st.header("Section 1 — CC/CV Simulation Engine")
    with st.form("simulation_form"):
        p = physical_inputs("sim_")
        c1, c2, c3 = st.columns(3)
        with c1:
            method = st.selectbox("Solver", ["RK4", "Heun", "Euler"], key="sim_method")
            policy = st.selectbox("Switch handling", ["Event-aware", "Grid-delayed"], key="sim_policy")
        with c2:
            dt = st.number_input("Step Δt (seconds)", 1., 3600., 60., 10., key="sim_dt")
            duration = st.number_input("Duration (seconds)", 60., 30000., 9000., 300., key="sim_duration")
        with c3:
            target = st.slider("Target SoC", .5, 1., .95, .01, key="sim_target")
            terminate = st.checkbox("Stop at termination current", value=False, key="sim_terminate")
        st.form_submit_button("Calculate simulation")
    try:
        result, trajectory, scores, figure = simulation_result(p, duration, dt, method, policy, terminate, target)
        cols = st.columns(4)
        for col, title, value in zip(cols, ["Exact CC → CV", "Detected CC → CV", "Numerical target time", "CV time constant"],
                                    [result["exact_switch_sec"], result["detected_switch_sec"], result["numerical_target_sec"], p.tau]):
            col.metric(title, time_text(value))
        st.write(f"Exact target: {time_text(result['exact_target_sec'])}. Exact practical termination: {time_text(result['exact_stop_sec'])}.")
        st.write("**Time to 100%:** " + time_text(result["time_to_100_percent_sec"]) + ". " + result["full_charge_note"])
        st.caption("Exact event times may lie beyond the plotted duration. Numerical target uses interpolation between nodes.")
        if p.mode == "CC": st.warning("Unregulated CC: interpret physically only before voltage or SoC limits are exceeded.")
        if dt/p.tau >= 1: st.warning("Δt/τ ≥ 1: inspect overshoot and unstable steps with termination off.")
        if (trajectory.soc_est > 1+1e-9).any() or (trajectory.soc_est < 0).any() or (trajectory.current_a < -1e-9).any():
            st.warning("Numerical trajectory left the physical domain. No state clipping was applied.")
        st.image(figure, caption="Exact and selected numerical time-domain charging curves")
        st.dataframe(scores, hide_index=True)
        result["numerical_metrics"] = scores.to_dict(orient="records")
        report["sections"]["simulation"] = result
        tables.update({"simulation_parameters": parameter_table(p, "simulation"), "trajectory": trajectory, "numerical_metrics": scores})
        figures["charging_curves"] = figure
    except ValueError as exc:
        st.error(str(exc)); report["errors"]["simulation"] = str(exc)

with tabs[1]:
    st.header("Section 2 — Numerical Solver & Convergence Lab")
    st.caption("Independent model and step-size controls. Termination is disabled to isolate solver order.")
    with st.form("numerical_form"):
        p_lab = physical_inputs("lab_")
        lab_dt = st.number_input("Base Δt (seconds)", 1., 1800., 60., 10., key="lab_dt")
        lab_duration = st.number_input("Study duration (seconds)", 60., 30000., 9000., 300., key="lab_duration")
        st.form_submit_button("Calculate convergence")
    try:
        rows, numerical_scores, defects, figure = numerical_result(p_lab, lab_duration, lab_dt)
        st.image(figure, caption="Error vs Δt: log-log, linear axes, and crossover timing lag")
        st.subheader("Global errors and crossover comparator"); st.dataframe(rows, hide_index=True)
        st.subheader("Live MAE, RMSE and maximum error — numerical vs exact"); st.dataframe(numerical_scores, hide_index=True)
        st.subheader("Isolated smooth-CV one-step defects"); st.dataframe(defects, hide_index=True)
        st.caption("One-step defects scale as h²/h³/h⁵; global state errors scale as h/h²/h⁴. CC is exact for all three. "
                   "Roundoff-level orders are omitted. The one-way latch prevents artificial mode chattering.")
        report["sections"]["numerical"] = {"parameters": asdict(p_lab), "duration_sec": lab_duration,
            "steps_sec": [lab_dt/4, lab_dt/2, lab_dt, lab_dt*2], "termination": False,
            "solver_metrics": numerical_scores.to_dict(orient="records")}
        tables.update({"numerical_lab_parameters": parameter_table(p_lab, "numerical_lab"), "convergence": rows,
                       "solver_metrics": numerical_scores, "local_defects": defects})
        figures["convergence_and_crossover"] = figure
    except ValueError as exc:
        st.error(str(exc)); report["errors"]["numerical"] = str(exc)

with tabs[2]:
    st.header("Section 3 — Experimental Overlay & Calibration")
    st.caption("Local model assumptions and fit results. Calibrating here leaves Sections 1 and 2 unchanged.")
    source = st.radio("Data source", ["Synthetic bench (not real measurements)", "Upload CSV", "No overlay"], key="fit_source")
    data = None
    if source.startswith("Synthetic"):
        data, truth = sample_data()
        st.caption("71 seeded synthetic samples; uninterrupted CV taper. Keep termination off.")
        with st.expander("Reveal synthetic ground truth"): st.json(asdict(truth))
    elif source == "Upload CSV":
        upload = st.file_uploader("CSV: time_sec, voltage_v, current_a, soc_est", type="csv", key="fit_upload")
        if upload is not None:
            try: data = load_csv(upload)
            except (ValueError, TypeError) as exc:
                st.error(f"Invalid CSV: {exc}"); report["errors"]["experimental_csv"] = str(exc)
    with st.form("calibration_form"):
        base = physical_inputs("fit_")
        fit_names = st.multiselect("Fit parameters", ["capacity_ah", "resistance_ohm", "soc0"],
                                   default=["capacity_ah", "resistance_ohm", "soc0"], key="fit_names")
        fit_terminate = st.checkbox("Include termination in model", value=False, key="fit_terminate")
        c1, c2, c3 = st.columns(3)
        with c1: sv = st.number_input("Voltage σ (V)", .0001, 1., .006, .001, format="%.4f", key="fit_sv")
        with c2: si = st.number_input("Current σ (A)", .0001, 1., .008, .001, format="%.4f", key="fit_si")
        with c3: ss = st.number_input("SoC σ (fraction)", .0001, .2, .003, .001, format="%.4f", key="fit_ss")
        st.form_submit_button("Calculate overlay")
        fit_button = st.form_submit_button("Auto-calibrate", disabled=data is None)
    try:
        base.validate()
        identity = json.dumps({"base": asdict(base), "terminate": fit_terminate, "names": fit_names, "sigma": [sv, si, ss]}, sort_keys=True)
        identity += source + ("" if data is None else data.to_csv(index=False))
        key = hashlib.sha256(identity.encode()).hexdigest()
        if fit_button:
            with st.spinner("Fitting exact CC/CV trajectories…"):
                fitted, info = calibrate(data, base, fit_names,
                    {"voltage_v": sv, "current_a": si, "soc_est": ss}, fit_terminate)
            st.session_state["calibration"] = (key, fitted, info)
        saved = st.session_state.get("calibration")
        fitted, info = (saved[1], saved[2]) if saved and saved[0] == key else (base, None)
        if info:
            if info["success"]: st.success("Calibration applied in Section 3. Metrics are in-sample.")
            else: st.warning("Optimizer did not converge; inspect diagnostics before using parameters.")
            for warning in info["warnings"]: st.warning(warning)
            st.json({n: getattr(fitted, n) for n in fit_names}, expanded=False)
        if data is None:
            st.info("Select a sample or upload CSV for overlays, residuals and fit errors.")
        else:
            before = comparison(data, exact(base, data.time_sec.to_numpy(), fit_terminate)).assign(fit="Before")
            after = comparison(data, exact(fitted, data.time_sec.to_numpy(), fit_terminate)).assign(fit="After" if info else "Uncalibrated")
            scores = pd.concat([before, after], ignore_index=True) if info else after
            st.dataframe(scores, hide_index=True)
            overlay, residual, predictions = calibration_figures(base, fitted, data, fit_terminate,
                "Synthetic bench" if source.startswith("Synthetic") else "Measured data")
            st.image(overlay); st.image(residual)
            st.write("**Residual = experiment − model.** Voltage residuals proportional to current suggest resistance/lead-drop error; "
                     "a signed current tail suggests taper or timing mismatch. These are hypotheses, not unique diagnoses. "
                     "Coulomb-counted SoC is correlated with the current used to compute it.")
            tables.update({"experiment": data, "experimental_metrics": scores, "predictions_and_residuals": predictions})
            figures.update({"experimental_overlay": overlay, "residuals": residual})
        report["sections"]["calibration"] = {"base_parameters": asdict(base), "parameters": asdict(fitted),
            "source": source, "termination": fit_terminate, "fit": info,
            "experimental_metrics": None if data is None else scores.to_dict(orient="records"),
            "exact_switch_sec": exact_events(fitted, fit_terminate)[0], "exact_stop_sec": exact_events(fitted, fit_terminate)[1]}
        tables["calibrated_parameters"] = parameter_table(fitted, "calibration" if info else "uncalibrated_overlay")
    except ValueError as exc:
        st.error(str(exc)); report["errors"]["calibration"] = str(exc)

with tabs[3]:
    st.header("Physics-style relationship experiments")
    st.write("At fixed SoC, current positive into the cell gives Vterm = VOC + RI, slope **+R**. "
             "The **−R** line uses positive outward discharge current. These are current sweeps at a fixed state, not a charging trajectory.")
    with st.form("physics_form"):
        p_physics = physical_inputs("phy_")
        fixed_soc = st.slider("Fixed SoC for Ohm's-law sweep", 0., 1., .5, .05, key="phy_fixed_soc")
        curvature = st.slider("Illustrative OCV curvature k/b", -.8, .8, .4, .05, key="phy_curvature")
        st.form_submit_button("Calculate physics relationships")
    try:
        figure, relationships = physics_result(p_physics, fixed_soc, curvature)
        st.image(figure, caption="Linear circuit/rate/CC relationships; curved OCV illustration; exponential and semilog taper")
        st.latex(r"U_{illustration}(s)=a+bs+ks(1-s),\quad |k|<b")
        st.caption("Curved OCV is an illustrative monotone alternative, not measured data or the engine/calibration law. "
                   "Curvature affects only this panel. Sweep points above Vmax describe the constitutive line, not attainable regulated charging.")
        report["sections"]["physics"] = {"parameters": asdict(p_physics), "fixed_soc": fixed_soc,
            "curvature_ratio": curvature, "curvature_v": p_physics.ocv_slope_v*curvature,
            "charging_slope_ohm": p_physics.resistance_ohm, "discharging_slope_ohm": -p_physics.resistance_ohm,
            "nonlinear_ocv_scope": "Illustration only; affine engine unchanged."}
        tables["physics_parameters"] = parameter_table(p_physics, "physics")
        tables.update({"physics_"+name: table for name, table in relationships.items()})
        figures["physics_relationships"] = figure
    except ValueError as exc:
        st.error(str(exc)); report["errors"]["physics"] = str(exc)

with tabs[4]:
    st.header("One-click presentation and report bundle")
    st.write("Summaries (TXT/Markdown/JSON), all available parameter/error/trajectory/relationship CSVs, "
             "300-dpi PNGs, and complete source with report and bilingual presentation guide.")
    if report["errors"]: st.warning("Some sections have invalid inputs. Their errors are recorded; fix them for a complete bundle.")
    st.caption("Apply each form before downloading; unsent edits are excluded.")
    package = build_bundle(report, tables, figures, root=ROOT)
    # Inspect the actual download payload in Streamlit integration tests.
    st.session_state["last_export_bytes"] = package
    st.session_state["last_export_report"] = report
    st.download_button("Download complete presentation ZIP", package, "charger_diagnostics.zip", "application/zip", key="export_zip")
    st.json(json_safe(report), expanded=False)
